const axios = require('axios')
/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */
exports.helloWorld = async (req, res) => {
  let email = req.query.email
  if (!email) {
    res.status(400).send("email not provided")  
  }
  const scriptURL = `https://script.google.com/macros/s/AKfycbx_Wg8GKV7fp_hae910yvuUzjpUbrWHPvCyRTyibdQOzQtgOTo/exec?sheetName=video_serial_number&email=${email}`
  try {
    
    const response = await axios.get(scriptURL)
    
    if (response.data.status !== "OK") {
      return res.send(response.data.message)
    }
    const code = response.data.values.code;
    const redirectURL = `https://www.myvideo.net.tw/SN-exchange/r/${code}`
    res.redirect(redirectURL);
  } catch(err) {
    res.send("err : " + err.message);
  }
};
